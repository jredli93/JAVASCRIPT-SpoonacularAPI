// The DOM element you wish to replace with Tagify
var input = document.querySelector("input[id=ingredients]");

// initialize Tagify on the above input node reference
new Tagify(input);
